# Online Auction App❤

This app is an online auction app which allows user to upload their valuable product and then they can organize an auction for that product
and once a user entered date is matched the campign gets over and the product is sold to the highest payer. 
This app is totally based on Firebase realtime database and firebase storage.


# App Screenshots🎉
This app has no ads and do not contains any in app purchases and is totally free. So if you want you can give it a try.
Just login and signup

<img src="images/1.jpeg" width="250">

Explore all the valueable and rare <b>Products List</b>👀

<img src="images/2.jpeg" width="250">

Add your own rare product for auction ✔

<img src="images/3.jpeg" width="250">

Here is the product description page ✔

<img src="images/4.jpeg" width="250">

and here you can enter your bid ✔

<img src="images/5.jpeg" width="250">

# License
Licensed under the [Apache Licence 2.0](LICENSE).
